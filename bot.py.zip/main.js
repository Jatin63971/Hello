import telebot

# 🔑 Aapke bot ka token (BotFather se)
BOT_TOKEN = "8056541604:AAGGbS6kgFaPEWEIodvvrrmqLF_P6Z5vyts"

# 📢 Users ko join karne wale channels
CHANNELS = [
    "https://t.me/EarnTechLoot",
    "https://t.me/EarntechGift",
    "https://t.me/LootBazzarHub",
    "https://t.me/ScretchEarn",
    "https://t.me/EarntechCampaign",
]

# 💸 Withdrawal request channel
WITHDRAWAL_CHANNEL = "@Earntechtrick"

# 📊 User data store karne ke liye dictionary
users = {}

bot = telebot.TeleBot(BOT_TOKEN)

# 🏁 Start Command
@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.chat.id
    if user_id not in users:
        users[user_id] = {"referrals": 0, "points": 0}

    referral_link = f"https://t.me/{bot.get_me().username}?start={user_id}"
    join_buttons = [telebot.types.InlineKeyboardButton(f"Join Channel {i+1}", url=CHANNELS[i]) for i in range(5)]
    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    keyboard.add(*join_buttons)
    keyboard.add(telebot.types.InlineKeyboardButton("✅ Verify", callback_data="verify"))

    bot.send_message(user_id, f"👋 Welcome!\n\n✅ Join all channels below and click 'Verify'.\n\n🔗 Your Referral Link: {referral_link}", reply_markup=keyboard)

# ✅ Verify Button
@bot.callback_query_handler(func=lambda call: call.data == "verify")
def verify(call):
    user_id = call.message.chat.id
    bot.answer_callback_query(call.id, "Verifying...")

    # Fake verification logic (Real implementation me API check required hoga)
    verified = True

    if verified:
        users[user_id]["points"] += 10  # Points dena
        bot.send_message(user_id, "✅ Verification Successful! You got 10 points.")
    else:
        bot.send_message(user_id, "❌ Please join all channels first!")

# 🔗 Referral System
@bot.message_handler(func=lambda message: message.text.startswith('/start '))
def referral_system(message):
    user_id = message.chat.id
    referrer_id = int(message.text.split()[1])

    if user_id not in users:
        users[user_id] = {"referrals": 0, "points": 0}

    if referrer_id in users and user_id != referrer_id:
        users[referrer_id]["referrals"] += 1
        users[referrer_id]["points"] += 5
        bot.send_message(referrer_id, f"🎉 You got a new referral! +5 points.")

    start(message)

# 💰 Check Points
@bot.message_handler(commands=['points'])
def check_points(message):
    user_id = message.chat.id
    points = users.get(user_id, {}).get("points", 0)
    bot.send_message(user_id, f"💰 Your Points: {points}")

# 💸 Withdrawal Request
@bot.message_handler(commands=['withdraw'])
def withdraw_request(message):
    user_id = message.chat.id
    points = users.get(user_id, {}).get("points", 0)

    if points < 50:  # Minimum points required for withdrawal
        bot.send_message(user_id, "❌ You need at least 50 points to withdraw.")
        return

    bot.send_message(WITHDRAWAL_CHANNEL, f"💸 New Withdrawal Request\nUser ID: {user_id}\nPoints: {points}")
    bot.send_message(user_id, "✅ Your withdrawal request has been sent!")

# 🚀 Bot Run
bot.polling()